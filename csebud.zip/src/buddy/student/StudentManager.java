package buddy.student;

public class StudentManager{
	
}