package buddy.timetable;

import buddy.timetable.Timetable;

public class TimetableFactory{
	
	public Timetable makeTimetable() // 시간표 객체 팩토리 메서드
	{
		return null;		
	}
	
}