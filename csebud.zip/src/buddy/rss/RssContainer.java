package buddy.rss;

public class RssContainer {
	public String title;
	public String link;
	public String author;
	public String date;

	public void setTitle(String title) {
		this.title = title;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public void setDate(String date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "FeedMessage [title=" + title + ", link=" + link + ", date= " + date + ", author=" + author + "]";
	}
}
